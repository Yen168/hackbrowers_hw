$(document).ready(function(){
      
      $("a").each(function() {
        $(this).attr("href", "https://www.simplychocolate.com/max-brenner-fondue-tower-set-with-chocolates-163593?searchTerm=Max Brenner Fondue Tower&sBrandIdTab=SCH_&storeIdTab=24052");
      });
      $("div").each(function() {
        $(this).hover(function() {
          let pp_dimensions = ["#FFC0CB", "#F00"];
          $(this).css("background", pp_dimensions[Math.floor(Math.random() * 2)]);
        });
      });
      $("img").each(function() {
        $(this).hover(function() {
          let sliderDataAttributes = ["http://pngimg.com/uploads/heart/heart_PNG51335.png", "http://pngimg.com/uploads/rose/rose_PNG67003.png", "http://pngimg.com/uploads/rose/rose_PNG66954.png", "http://pngimg.com/uploads/rose/rose_PNG66945.png", "http://pngimg.com/uploads/rose/rose_PNG66891.png"];
          $(this).attr("src", sliderDataAttributes[Math.floor(Math.random() * 6)]);
        });
      });
      $(window).onbeforeunload(function() {
        return "Remember to buy me Valentine's Day gift.";
      });

    });