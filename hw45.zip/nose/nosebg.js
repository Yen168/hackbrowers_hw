// var video = document.getElementById('video');

// // Get access to the camera!
// if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
//     // Not adding `{ audio: true }` since we only want video now
//     navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {
//         //video.src = window.URL.createObjectURL(stream);
//         video.srcObject = stream;
//         video.play();
//     });
// }




var poseNose = null;
var noseX = null;
var noseY = null;

window.onload = function(){


var video = document.getElementById('video');

const poseNet = ml5.poseNet(video, modelLoaded);

// Listen to new 'pose' events
poseNet.on("pose", function(results) {
  
  poses = results;

  if (poses['0']['pose']['keypoints'][0]['position']['x']){

    noseX = poses['0']['pose']['keypoints'][0]['position']['x'];

  }

  if(noseY = poses['0']['pose']['keypoints'][0]['position']['y']){

    noseY = poses['0']['pose']['keypoints'][0]['position']['y'];

  }
  
  
  //console.log(noseX);

});
 

// Get access to the camera!
if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    // Not adding `{ audio: true }` since we only want video now
    navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {
        //video.src = window.URL.createObjectURL(stream);
        video.srcObject = stream;
        video.play();
    });
}
};

function modelLoaded() {
  console.log("Model Loaded!");
}

function sendToBG(){

  chrome.runtime.sendMessage({type:1,noseX:noseX,noseY:noseY});

  //console.log('Sent');

}

setInterval(sendToBG, 500);

