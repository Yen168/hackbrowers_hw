

function sendToBG2(){

  chrome.runtime.sendMessage({type:123});

  //console.log('Sent');

}

setInterval(sendToBG2, 500);

