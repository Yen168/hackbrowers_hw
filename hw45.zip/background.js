
var noseWin;
var noseHtml = chrome.extension.getURL('nose/nose.html');

var noseX = 0;
var noseY = 0;


chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse){

  if (msg.noseX) {noseX = msg.noseX};
  if (msg.noseY) {noseY = msg.noseY};

  if(msg.type === 123 ){

    noseWin.moveTo(noseX, noseY);

  }


});


chrome.browserAction.onClicked.addListener(function(tab) {

	
  var url = 'nose/nosebg.html';
var w = 600;
    var h = 800;
	var left = (screen.width/2)-(w/2);
    var top = (screen.height/2)-(h/2); 
 		

  chrome.windows.create({
    type: "popup",
    width: w,
    height: h,
    left: left,
    top: top,
    url: url
  }, function(win) {

    noseWin = window.open(noseHtml, '', 'width=20, height=20');
    
  });
});